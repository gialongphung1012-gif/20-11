import { getStore } from "@netlify/blobs";
import { createHash, timingSafeEqual, randomUUID } from "node:crypto";

export const config = { path: "/api/*" };

const MAX_IMAGE = 4.5 * 1024 * 1024;
const MAX_MUSIC = 4.5 * 1024 * 1024;

const store = () => getStore({ name: "lop919", consistency: "strong" });

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
  });

const sha = (s) => createHash("sha256").update(String(s)).digest();

function isAdmin(req) {
  const expected = process.env.ADMIN_PASSWORD || "9a192026-2027";
  const given = req.headers.get("x-admin-password") || "";
  return timingSafeEqual(sha(given), sha(expected));
}

async function readState(s) {
  const st = await s.get("state", { type: "json" });
  return st && Array.isArray(st.photos) ? st : { photos: [], music: null };
}

function publicState(st) {
  return {
    photos: st.photos.map((p) => ({
      id: p.id,
      caption: p.caption,
      url: `/api/img/${p.id}?v=${p.v}`,
    })),
    music: st.music ? { name: st.music.name, url: `/api/music?v=${st.music.v}` } : null,
  };
}

function binResponse(req, buf, type) {
  const total = buf.byteLength;
  const h = {
    "Content-Type": type,
    "Accept-Ranges": "bytes",
    "Cache-Control": "public, max-age=31536000, immutable",
  };
  const range = req.headers.get("range");
  const m = range && /bytes=(\d*)-(\d*)/.exec(range);
  if (m && (m[1] !== "" || m[2] !== "")) {
    let start, end;
    if (m[1] === "") {
      start = Math.max(0, total - Number(m[2]));
      end = total - 1;
    } else {
      start = Number(m[1]);
      end = m[2] === "" ? total - 1 : Math.min(Number(m[2]), total - 1);
    }
    if (start > end || start >= total) {
      return new Response(null, { status: 416, headers: { "Content-Range": `bytes */${total}` } });
    }
    h["Content-Range"] = `bytes ${start}-${end}/${total}`;
    h["Content-Length"] = String(end - start + 1);
    return new Response(buf.slice(start, end + 1), { status: 206, headers: h });
  }
  h["Content-Length"] = String(total);
  return new Response(buf, { status: 200, headers: h });
}

const safeDecode = (v, fallback = "") => {
  try { return decodeURIComponent(v || ""); } catch { return fallback; }
};

export default async (req) => {
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean);
  const [res, id] = parts;
  const method = req.method;
  const s = store();

  try {
    /* ---------- CÔNG KHAI: chỉ đọc ---------- */
    if (method === "GET" && res === "state") {
      return json(publicState(await readState(s)));
    }

    if (method === "GET" && res === "img" && id) {
      const st = await readState(s);
      const p = st.photos.find((x) => x.id === id);
      const buf = p && (await s.get("img-" + id, { type: "arrayBuffer" }));
      if (!buf) return new Response("Not found", { status: 404 });
      return binResponse(req, buf, p.type || "image/jpeg");
    }

    if (method === "GET" && res === "music") {
      const st = await readState(s);
      const buf = st.music && (await s.get("music", { type: "arrayBuffer" }));
      if (!buf) return new Response("Not found", { status: 404 });
      return binResponse(req, buf, st.music.type || "audio/mpeg");
    }

    /* ---------- QUẢN TRỊ: cần mật khẩu ---------- */
    if (!["login", "photos", "music"].includes(res)) return json({ error: "Not found" }, 404);

    if (!isAdmin(req)) {
      await new Promise((r) => setTimeout(r, 600));
      return json({ error: "Sai mật khẩu" }, 401);
    }

    if (res === "login" && method === "POST") return json({ ok: true });

    /* --- ẢNH --- */
    if (res === "photos") {
      const st = await readState(s);

      if (method === "POST" && !id) {
        const type = req.headers.get("content-type") || "";
        if (!type.startsWith("image/")) return json({ error: "File không phải ảnh" }, 400);
        const buf = await req.arrayBuffer();
        if (!buf.byteLength) return json({ error: "File rỗng" }, 400);
        if (buf.byteLength > MAX_IMAGE) return json({ error: "Ảnh quá lớn (tối đa 4.5MB)" }, 413);
        const pid = randomUUID().slice(0, 12);
        await s.set("img-" + pid, buf);
        st.photos.push({
          id: pid,
          caption: safeDecode(req.headers.get("x-caption")).slice(0, 200) || "Kỷ niệm đẹp cùng Cô",
          type,
          v: Date.now().toString(36),
        });
        await s.setJSON("state", st);
        return json(publicState(st));
      }

      const idx = st.photos.findIndex((p) => p.id === id);
      if (idx < 0) return json({ error: "Không tìm thấy ảnh" }, 404);

      if (method === "PUT") {
        const type = req.headers.get("content-type") || "";
        if (!type.startsWith("image/")) return json({ error: "File không phải ảnh" }, 400);
        const buf = await req.arrayBuffer();
        if (!buf.byteLength) return json({ error: "File rỗng" }, 400);
        if (buf.byteLength > MAX_IMAGE) return json({ error: "Ảnh quá lớn (tối đa 4.5MB)" }, 413);
        await s.set("img-" + id, buf);
        st.photos[idx].type = type;
        st.photos[idx].v = Date.now().toString(36);
        await s.setJSON("state", st);
        return json(publicState(st));
      }

      if (method === "PATCH") {
        let body;
        try { body = await req.json(); } catch { return json({ error: "Dữ liệu sai" }, 400); }
        if (typeof body.caption === "string") st.photos[idx].caption = body.caption.slice(0, 200);
        if (body.move === -1 || body.move === 1) {
          const to = idx + body.move;
          if (to >= 0 && to < st.photos.length) {
            [st.photos[idx], st.photos[to]] = [st.photos[to], st.photos[idx]];
          }
        }
        await s.setJSON("state", st);
        return json(publicState(st));
      }

      if (method === "DELETE") {
        st.photos.splice(idx, 1);
        await s.setJSON("state", st);
        await s.delete("img-" + id);
        return json(publicState(st));
      }
    }

    /* --- NHẠC --- */
    if (res === "music") {
      const st = await readState(s);

      if (method === "PUT") {
        const type = req.headers.get("content-type") || "";
        if (!type.startsWith("audio/")) return json({ error: "File không phải nhạc" }, 400);
        const buf = await req.arrayBuffer();
        if (!buf.byteLength) return json({ error: "File rỗng" }, 400);
        if (buf.byteLength > MAX_MUSIC) return json({ error: "Nhạc quá lớn (tối đa 4.5MB)" }, 413);
        await s.set("music", buf);
        const name = safeDecode(req.headers.get("x-filename")).replace(/\.[^/.]+$/, "").slice(0, 100) || "Nhạc nền";
        st.music = { name, type, v: Date.now().toString(36) };
        await s.setJSON("state", st);
        return json(publicState(st));
      }

      if (method === "DELETE") {
        st.music = null;
        await s.setJSON("state", st);
        await s.delete("music");
        return json(publicState(st));
      }
    }

    return json({ error: "Method not allowed" }, 405);
  } catch (e) {
    console.error(e);
    return json({ error: "Lỗi máy chủ: " + (e && e.message ? e.message : e) }, 500);
  }
};
