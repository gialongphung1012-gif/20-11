# Thiệp tri ân 20/11 – Lớp 9/19

## Cấu trúc
- `public/index.html`  → trang của Cô (không có bất kỳ phần quản trị nào)
- `public/admin.html`  → trang quản trị, vào bằng `link-netlify/admin`
- `public/nhac.mp3`    → nhạc mặc định
- `netlify/functions/api.mjs` → máy chủ lưu ảnh/nhạc + kiểm tra mật khẩu

## Đưa lên Netlify (không kéo-thả được vì cần cài package)
### Cách 1: GitHub
1. Tạo repo GitHub, đẩy toàn bộ thư mục này lên.
2. Netlify → Add new site → Import from Git → chọn repo. Không cần Build command, Publish directory là `public` (đã có trong netlify.toml).
3. Site configuration → Environment variables → thêm `ADMIN_PASSWORD` = mật khẩu của bạn → Deploy lại.

### Cách 2: Netlify CLI
```
npm install
npm i -g netlify-cli
netlify login
netlify init        # (hoặc netlify link nếu đã có site)
netlify env:set ADMIN_PASSWORD "mat-khau-cua-ban"
netlify deploy --prod
```

## Dùng
- Cô/học sinh: `https://ten-site.netlify.app`
- Quản trị: `https://ten-site.netlify.app/admin` → nhập mật khẩu → thêm/sửa/xoá/sắp xếp ảnh, đổi nhạc. Trang của Cô tự cập nhật (tối đa ~15 giây nếu đang mở sẵn).
- Lớp không có mạng: vào /admin → "Tải file offline về máy" → được `Tri-An-Co-20-11.html`, chép vào USB/điện thoại, nhấp đúp là chạy (ảnh + nhạc đã nhúng sẵn).

## Lưu ý
- Nếu không đặt `ADMIN_PASSWORD`, mật khẩu mặc định là `9a192026-2027` (nằm trong api.mjs). Nên đặt biến môi trường và đừng để repo public nếu giữ mật khẩu mặc định.
- Nhạc tối đa 4MB, mỗi ảnh được tự nén trước khi tải lên.
- Khoá JSONBin cũ đã bị lộ trong bản trước, không còn dùng nữa: nên xoá/đổi khoá đó trên jsonbin.io.
